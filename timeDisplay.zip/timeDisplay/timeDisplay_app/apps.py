from django.apps import AppConfig


class TimedisplayAppConfig(AppConfig):
    name = 'timeDisplay_app'
