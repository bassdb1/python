from django.apps import AppConfig


class LoginregAppConfig(AppConfig):
    name = 'loginReg_app'
