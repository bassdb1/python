from django.urls import path
from . import views
                    
urlpatterns = [
    path('', views.index),
    
    # path object
    path('submit_form', views.handle_form),

    path('go_back', views.handle_return),

]

