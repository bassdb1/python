from django.shortcuts import render, HttpResponse, redirect

# Create your views here.
def index(request):
    return render(request,"index.html")
    # request is what the users computer sends to us

def handle_form(request):
    # request.Post is what is in the Form Data. 'Request.Post is a dictionary

    #print(request.POST) - will display on the terminal window

    # this is where the page will be returned too.  The home page '/'

    # return redirect('/')

    # If I 'only' wanted the users name from 'request.POST' I could do this
    #   print(request.POST['full_name'])

    # **** If I used a 'GET' instead of a 'POST' I would get the URL data, along with the form data.  I would only want to do this if I was doing a 'Search Box'

# if I want to send this to another HTML page, I could do this.

    # To pass any 'data' I will need a 'context' dictionary
       # The 'key' on the context dictionary is 'full_name': 
       # request.POST['full_name] is the data from the form, and we are storing the data from the form in the 'full_name' key

    context = {
        'full_name': request.POST['full_name'],
        'dojo': request.POST['dojo'],
        'language': request.POST['language'],
        'dojo': request.POST['dojo'],
        'message': request.POST['message']        

    }

    # this will be using 'request' to get the data from the users computer
    #... 'results.html' is where we want to place the data
    # ... 'context' is saying we are getting the data from the 'context dictionary'
    return render(request, "results.html", context)

def handle_return(request):
    return redirect('/')
    

