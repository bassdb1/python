from django.db import models

# Create your models here.
class Tv_Shows(models.Model):
    title = models.CharField(max_length=255)
    network = models.CharField(max_length=20)
    description = models.TextField()
    release_date = models.DateTimeField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
