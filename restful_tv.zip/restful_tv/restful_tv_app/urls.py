from django.urls import path
from .import views
urlpatterns = [
    path('', views.root),
    path('shows', views.shows),
    path('shows/new', views.create_show),
    path('/tv_show/create', views.create_tv_shows), 
#     path('shows/<int:tv_shows_id'>,views.info_show),
#     path('shows/<int:tv_shows_id>/edit', views.edit_show),
 ]

