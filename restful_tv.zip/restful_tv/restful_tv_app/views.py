from django.shortcuts import render, HttpResponse,redirect

from .models import Tv_Shows

# Create your views here.

def root(request):
    return redirect('/shows')

#This will show the shows in the database
def shows(request):

    context ={'tv_shows': Tv_Shows.objects.all()

    }
    return render(request, "shows.html", context)

def create_show(request):
    return render(request, 'shows_create.html')

def create_tv_shows(request):
    print(request.POST)
    new_show = Tv_Shows.objects.create(
        title = request.POST['title'],
        network = request.POST['network'],
        description = request.POST['description'],
        release_date = request.POST['release_date']

    )
    return redirect(f'/shows/{new_show.id}')

def info_show(request, show_id):
    print(request)
    context = {
        'view_show':Tv_Shows.get(id = show_id)
    }
    return render(request, 'shows_one.html', context)

def edit_show(request, show_id):
    context = {
        'edit_show':Tv_Shows.get(id = show_id)
    }
    return render(request, 'shows_edit.html', context)




