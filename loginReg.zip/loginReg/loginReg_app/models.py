from django.db import models
import re

# Validator to check email and passwords
class UserManager(models.Manager):

    
    def basic_validator(self, post_data):
        errors = {}

        # checks that the name has at least 'two characters'

        if len(post_data['first_name']) < 2:
            errors ['first_name_length'] = 'First Names shoule be greater than 2 characters.'

        if len(post_data['last_name']) < 2:
            errors ['last_name_length'] = 'First Names shoule be greater than 2 characters.'

        # checks the email format

        email_regex = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        
        if not email_regex.match(post_data['email']):
            errors['email_pattern'] = 'Please enter a valid email address'
        
        # checks for password length

        if len(post_data['password']) <8:
            errors['password_length'] = 'Password needs to be at least eight characters in length.'
        
        # checks for password matching
        
        if not post_data['password'] == post_data ['confirm_password']:
            errors['password_match'] = 'Passwords must match'
        
        return errors


# Create your models here.
class User(models.Model):
    first_name = models.CharField(max_length = 30)
    last_name = models.CharField(max_length = 30)
    email = models.CharField(max_length = 320)
    password = models.CharField(max_length = 60)
    created_at = models.DateTimeField(auto_now_add = True)
    updated_at = models.DateTimeField(auto_now = True)
    objects = UserManager()

# Next step make migrations to setup database User model

