def generate_board(width,height):
    # width is width, height is height
    # board[height][width] - gets me the item at x(width), y(height) if stating at the upper left corner
    board = []
    for y in range(0, height):
        new_row = []
        for x in range(0, width):
            if (x + y) %2 == 0:
                new_row.append(0)
            else:
                new_row.append((x+y) %2)
        board.append(new_row)
        

    return board

print (generate_board(4,4))