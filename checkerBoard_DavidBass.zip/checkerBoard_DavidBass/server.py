from flask import Flask, render_template 
# Import the function 'generate_board' from the test.py file.  Cool! 
from test import generate_board
app = Flask(__name__)  # New object app, Instance of the Flask class

@app.route('/')
def checkerboard1():
    board = generate_board(8, 8)
    return render_template("board.html", board = board)  

@app.route('/<int:height>')
def checkerboard2(height):
    board = generate_board(8, height)
    return render_template("board.html",  board = board)  


@app.route('/<int:width>/<int:height>')
def checkerboard3(width, height):
    board = generate_board(width, height)
    return render_template("board.html", board = board)        

if __name__ == "__main__":   # need this
    app.run(debug = True)
