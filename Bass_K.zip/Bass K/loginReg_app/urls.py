from django.urls import path
from . import views
urlpatterns = [
    path('', views.index),
    #route for the registration of the user, first part is the URL, 
    # second is the views path 'views.register_user'
    path('users/register', views.register_user),
    #route for the login of the user
    path('users/login', views.login_user),
    # path('success', views.success),
    path('users/logout',views.logout),

]