from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
# import bcrypt for password hashing
import bcrypt
# Imports the User Database
from .models import User    

# Create your views here.
def index(request):
    return render(request, "login.html")

def register_user(request):
    # display errors
    errors = User.objects.basic_validator(request.POST)
    if errors:
        for k, v in errors.items():
            messages.error(request, v)
        return redirect('/')
    else:
       
        # hashing the password, first part is the code we wish to hash, second part is the 'salt' which is a unique string attached to the password, .decode turns it back into text, so it can be stored in the database

        pw_hash = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt()).decode()
        

     

    
    #create a user
    User.objects.create(
        first_name = request.POST['first_name'],
        last_name = request.POST['last_name'],
        email = request.POST['email'],
        # be sure to pass the hashed password
        password = pw_hash
        
    )

    messages.info(request, "User created successfully, log in now!")


    return redirect('/')

def login_user(request):
    try:
        user = User.objects.get(email = request.POST ['email'])
    except:
        messages.error(request, "Email not found")
        return redirect ('/')

    if not bcrypt.checkpw(request.POST['password'].encode(), user.password.encode()):
        messages.error(request, 'Password incorrect.')
        return redirect('/')
    # the following will determine if a user is logged in or not. We can also use this to get the user object.  'This will also put the users id in session'
    request.session['user_id'] = user.id
    request.session['first_name'] = user.first_name
    return redirect('/exam')
    
    # used to go the success.html page
    # return redirect('/success')
    #used to direct the user to the success.html page

# def success(request):
#     if 'user_id' not in request.session:
#         messages.error(request, 'Please log in to see this page')
#         return redirect('/')
#     return render(request, "success.html")

def logout(request):
    if 'user_id' in request.session:
        del request.session['user_id']
    if 'first_name' in request.session:
        del request.session['first_name']
    return redirect('/')
