
from django.urls import path
from . import views
urlpatterns = [
    path('', views.index),
    path('jobs/new', views.new_job),
    path('jobs/create', views.create_job),
    path('jobs/<int:job_id>', views.single_job),
    path('jobs/<int:job_id>/edit', views.edit_job),
    path('jobs/<int:job_id>/update', views.update_job),
    path('jobs/<int:job_id>/delete', views.delete_job)

]