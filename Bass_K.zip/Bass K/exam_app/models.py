from django.db import models
from loginReg_app.models import User

# Create your models here.

class JobManager(models.Manager):

    def basic_validator(self, post_data):
        errors = {}

        if len(post_data['job_title']) < 3:
            errors['job_title'] = "Job Title must be at least 3 characters"

        if len(post_data['job_description']) < 3:
             errors['job_description'] = "Job Description must be at least 3 characters"

        if len(post_data['job_location']) < 3:
            errors['job_location'] = "Job Location must be at least 3 characters"

        return errors

class Job(models.Model):
    title = models.CharField(max_length = 50)
    description = models.CharField(max_length = 50)
    location = models.CharField(max_length = 50)
    creator = models.ForeignKey(User,related_name = 'created_jobs', on_delete = models.CASCADE)
    attending_users = models.ManyToManyField(User, related_name = 'jobs_working')
    created_at = models.DateTimeField(auto_now_add = True)
    updated_at = models.DateTimeField(auto_now = True)
    objects = JobManager()


