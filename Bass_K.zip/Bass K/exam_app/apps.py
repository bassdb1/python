from django.apps import AppConfig


class ExamAppConfig(AppConfig):
    name = 'exam_app'
