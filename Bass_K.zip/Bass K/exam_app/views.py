from django.shortcuts import render, redirect, HttpResponse
from django.contrib import messages
from loginReg_app.models import User
from .models import Job

# Create your views here.
def index(request):
    context = {
        'jobs': Job.objects.all()
    }
    return render(request, "index.html", context)

def new_job(request):
    return render(request, "new_job.html")

def create_job(request):
    errors = Job.objects.basic_validator(request.POST)
    
    if errors:
        for k, v in errors.items():
            messages.error(request, v)
        return redirect ('/exam/jobs/new')

    else:
        Job.objects.create(
            title = request.POST['job_title'],
            description = request.POST['job_description'],
            location = request.POST['job_location'],
            creator = User.objects.get(id = request.session['user_id'])
        )
        return redirect('/exam')

def single_job(request, job_id):
    context = {
        'job': Job.objects.get(id=job_id)
    }
    return render(request,"single_job.html", context)

def update_job(request, job_id):
    errors = Job.objects.basic_validator(request.POST)
    if errors:
        for k, v in errors.items():
            messages.error(request, v)
        return redirect(f'/exam/jobs/{job_id}/edit')
    else:
        job = Job.objects.get(id = job_id)
        job.title = request.POST['job_title']
        job.description = request.POST['job_description']
        job.location = request.POST['job_location']
        job.save()
        return redirect('/exam')


# def edit_job(request):
#      return render(request, "edit_job.html")


def edit_job(request, job_id):
    context = {
        'job': Job.objects.get(id=job_id)
    }
    return render(request,"edit_job.html", context)

def delete_job(request, job_id):
    job = Job.objects.get(id = job_id)
    job.delete()
    return redirect('/exam')


    
    


