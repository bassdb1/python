from django.shortcuts import render, HttpResponse, redirect


# Import my database - 'Users'
from .models import Users


def index (request):
# adding a 'Context Dictionary' - to display data on the website
    context = {
        # this will get a list off all users from the Database
        'users': Users.objects.all()
    }

# Create your views here.

    return render(request, "index.html", context)

def create_user(request):
    print(request.POST)
    Users.objects.create(
        first_name = request.POST['first_name'],
        last_name = request.POST['last_name'],
        email_address = request.POST['email_address'],
        age = request.POST['age']

        )
    return redirect('/')