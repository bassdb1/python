from django.apps import AppConfig


class CounterAppConfig(AppConfig):
    name = 'counter_app'
