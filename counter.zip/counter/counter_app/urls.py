from django.urls import path
from .import views

urlpatterns = [
    path('', views.index),
    # path('counter_page', views.counter_page),
    path('counter_page', views.counter_page),
    path('increment_counter/<int:counter_id>', views.increment_counter),
    path('reset_counter', views.reset_counter)
]

