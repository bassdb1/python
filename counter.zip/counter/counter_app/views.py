from django.shortcuts import render, HttpResponse, redirect

# Create your views here.
def index(request):
    return HttpResponse("This is and @app route")


def counter_page(request):
    if 'counter_1'not in request.session:
        request.session['counter_1'] = 0
    return render(request, "counter_page.html")

def increment_counter(request, counter_id):
    if counter_id == 1:
        request.session['counter_1'] +=1

    return redirect('/counter_page')

def reset_counter(request):
  
    if 'counter_1' in request.session:
        del request.session['counter_1']
    return redirect('/counter_page')

