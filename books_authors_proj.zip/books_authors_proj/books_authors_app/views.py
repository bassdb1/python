from django.shortcuts import render, HttpResponse, redirect
# we will need to import our DB's (Books, Authors), or (models) to use it in our webpage,

from .models import Books  # I may do import * since I have multiple databases
# Create your views here.
def index(request):
    # 'render' an HTML page called "index.html", show stuff on the page, 'context' dictionry, so I need to look and see what I need to show, and adjust accordingly\
    context = {'books': Books.objects.all()

    }  

    return render(request, "index.html", context)

def create_books(request):
    # Print statement will print to the console. I do this to make sure it is working
    print(request.POST)
    # Writes to the database 'Books', using 'objects.create' to create new objects in the Books Database
    Books.objects.create(
    # Fields in the 'Books' database that will be written too
        title = request.POST['title'],
        desc = request.POST['description'],
    )
    # redirects the webpage back to the home page because of '/'.  I needed redirect at the top too.
    return redirect('/')