from flask import Flask, render_template  
app = Flask(__name__)  # New object app, Instance of the Flask class

@app.route('/')
def functionHome():
    return "This page works"

@app.route('/play')
def playGround1():
    return render_template("index1.html") 


@app.route('/play/<times>')
def playGround2(times):
    return render_template("boxes2.html", num_times = int(times)) 
    

@app.route('/play/<times>/<color>')
def playGround(times, color):
    return render_template("boxes.html", num_times = int(times), some_color = color) 
    

if __name__ == "__main__":   # need this
    app.run(debug = True)



