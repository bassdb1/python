from django.shortcuts import render, HttpResponse

# Create your views here.
def index(request):
    return HttpResponse("I'm a view!")


def route2(request):
    return HttpResponse("I'm a different route!")

def multiply(request, number_one, number_two):
    return HttpResponse(f"The result of {number_one} and {number_two} is: {number_one * number_two} ")

def index(request):
    return HttpResponse("placeholder to later display a list of all blogs")

def number(request, blog_number):
    return HttpResponse(f"placeholder to display blog number {blog_number}")

def new(request):
    return HttpResponse("placeholder to display a new form to create a new blog")

def edit(request, edit_number):
    return HttpResponse(f"placeholder to edit blog number {edit_number} with a method named 'edit'")
