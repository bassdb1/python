from django.urls import path
from .import views
urlpatterns = [
    path('', views.index),
    path('route2', views.route2),
    path('<int:number_one>/<int:number_two>', views.multiply),
    path('blogs', views.index),
    path('blogs/<int:blog_number>', views.number),
    path('blogs/new', views.new),
    path('blogs/edit/<int:edit_number>', views.edit),
]