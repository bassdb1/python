from django.apps import AppConfig


class FirstProjectAppConfig(AppConfig):
    name = 'first_project_app'
